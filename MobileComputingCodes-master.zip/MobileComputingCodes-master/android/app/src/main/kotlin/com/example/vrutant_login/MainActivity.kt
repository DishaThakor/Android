package com.example.vrutant_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
