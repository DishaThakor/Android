package com.example.all_programms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
