import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class MealsHomePage extends StatefulWidget {
  @override
  _MealsHomePageState createState() => _MealsHomePageState();
}

class _MealsHomePageState extends State<MealsHomePage> {
  List<dynamic> meals = [];
  List<dynamic> filteredMeals = [];
  List<dynamic> favoriteMeals = [];
  String filterType = 'All';
  String searchText = '';

  @override
  void initState() {
    super.initState();
    fetchMeals();
  }

  // Fetch meals from TheMealDB API
  Future<void> fetchMeals() async {
    final response = await http.get(Uri.parse('https://www.themealdb.com/api/json/v1/1/search.php?s='));
    if (response.statusCode == 200) {
      setState(() {
        meals = json.decode(response.body)['meals'];
        filteredMeals = meals;
      });
    } else {
      throw Exception('Failed to load meals');
    }
  }

  // Toggle favorite meal
  void toggleFavorite(String mealId) {
    setState(() {
      if (favoriteMeals.contains(mealId)) {
        favoriteMeals.remove(mealId);
      } else {
        favoriteMeals.add(mealId);
      }
    });
  }

  // Search function
  void searchMeals(String text) {
    setState(() {
      searchText = text;
      filterMeals();
    });
  }

  // Filter meals based on type (Veg/Non-Veg)
  void filterMeals() {
    setState(() {
      filteredMeals = meals.where((meal) {
        // Check for Veg/Non-Veg types (Here, we check if the meal contains "vegetarian" in its name)
        if (filterType != 'All' && !(filterType == 'Veg' ? meal['strCategory'] == 'Vegetarian' : meal['strCategory'] != 'Vegetarian')) {
          return false;
        }
        if (searchText.isNotEmpty && !meal['strMeal'].toLowerCase().contains(searchText.toLowerCase())) {
          return false;
        }
        return true;
      }).toList();
    });
  }

  // Change filter
  void changeFilter(String type) {
    setState(() {
      filterType = type;
      filterMeals();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Meals App'),
        actions: [
          IconButton(
            icon: Icon(Icons.favorite),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => FavoritesPage(favoriteMeals: favoriteMeals, meals: meals)),
              );
            },
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Search',
                border: OutlineInputBorder(),
              ),
              onChanged: searchMeals,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FilterButton(
                label: 'All',
                selected: filterType == 'All',
                onTap: () => changeFilter('All'),
              ),
              FilterButton(
                label: 'Veg',
                selected: filterType == 'Veg',
                onTap: () => changeFilter('Veg'),
              ),
              FilterButton(
                label: 'Non-Veg',
                selected: filterType == 'Non-Veg',
                onTap: () => changeFilter('Non-Veg'),
              ),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredMeals.length,
              itemBuilder: (context, index) {
                final meal = filteredMeals[index];
                final isFavorite = favoriteMeals.contains(meal['idMeal']);
                return ListTile(
                  title: Text(meal['strMeal']),
                  subtitle: Text(meal['strCategory']),
                  trailing: IconButton(
                    icon: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: isFavorite ? Colors.red : null,
                    ),
                    onPressed: () => toggleFavorite(meal['idMeal']),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class FilterButton extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  FilterButton({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: selected ? Colors.deepPurple : Colors.grey,
        ),
        child: Text(label),
        onPressed: onTap,
      ),
    );
  }
}

class FavoritesPage extends StatelessWidget {
  final List<dynamic> favoriteMeals;
  final List<dynamic> meals;

  FavoritesPage({required this.favoriteMeals, required this.meals});

  @override
  Widget build(BuildContext context) {
    final favoriteList = meals.where((meal) => favoriteMeals.contains(meal['idMeal'])).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text('Favorite Meals'),
      ),
      body: ListView.builder(
        itemCount: favoriteList.length,
        itemBuilder: (context, index) {
          final meal = favoriteList[index];
          return ListTile(
            title: Text(meal['strMeal']),
            subtitle: Text(meal['strCategory']),
          );
        },
      ),
    );
  }
}
