import 'package:flutter/material.dart';

class ExpenseHomePage extends StatefulWidget {
  @override
  _ExpenseHomePageState createState() => _ExpenseHomePageState();
}

class _ExpenseHomePageState extends State<ExpenseHomePage> {
  // List to store the expenses as a map (with name and amount)
  List<Map<String, dynamic>> expenses = [];

  // Controllers to handle input fields
  final TextEditingController _expenseNameController = TextEditingController();
  final TextEditingController _expenseAmountController = TextEditingController();

  // Method to add new expense to the list
  void _addExpense() {
    if (_expenseNameController.text.isNotEmpty && _expenseAmountController.text.isNotEmpty) {
      setState(() {
        expenses.add({
          'name': _expenseNameController.text,
          'amount': double.parse(_expenseAmountController.text),
        });
        // Clear the input fields after adding
        _expenseNameController.clear();
        _expenseAmountController.clear();
      });
    }
  }

  // Method to calculate the total of all expenses
  double getTotalExpense() {
    return expenses.fold(0, (sum, item) => sum + item['amount']);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Expense App')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Input fields for new expense (name and amount)
            Row(
              children: [
                // Expense name input
                Expanded(
                  child: TextField(
                    controller: _expenseNameController,
                    decoration: InputDecoration(
                      labelText: 'Expense Name',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                // Expense amount input
                Expanded(
                  child: TextField(
                    controller: _expenseAmountController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Amount',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: _addExpense, // Add new expense on button press
                  child: Text('Add'),
                ),
              ],
            ),
            SizedBox(height: 20),
            // Display the list of expenses
            Expanded(
              child: ListView.builder(
                itemCount: expenses.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(expenses[index]['name']),
                    trailing: Text('\₹${expenses[index]['amount'].toStringAsFixed(2)}'),
                  );
                },
              ),
            ),
            // Display the total expense at the bottom
            Container(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'Total: \₹${getTotalExpense().toStringAsFixed(2)}',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: ExpenseHomePage(),
  ));
}
