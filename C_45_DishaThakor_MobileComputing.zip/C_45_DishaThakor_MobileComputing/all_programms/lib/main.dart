import 'package:all_programms/screens/meals_home_page.dart';
import 'package:all_programms/screens/weather_home_page.dart';
import 'package:flutter/material.dart';
import 'screens/login_page.dart';
import 'screens/bmi_calculator_page.dart';
import 'screens/expense_home_page.dart';
import 'screens/calculator_home_page.dart';
import 'screens/news_home_page.dart';
import 'widgets/app_button.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Multiple Apps',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Apps Menu'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          AppButton(
            title: 'Login & Registration',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LoginPage())),
          ),
          AppButton(
            title: 'BMI Calculator',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BMICalculatorPage())),
          ),
          AppButton(
            title: 'Expense App',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExpenseHomePage())),
          ),
          AppButton(
            title: 'Calculator',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CalculatorHomePage())),
          ),
          AppButton(
            title: 'News App',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NewsHomePage())),
          ),

          AppButton(
            title: 'Meals App',  // New App added to the list
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MealsHomePage())),
          ),

          AppButton(
            title: 'Weather App', // New Weather App
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WeatherHomePage())),
          ),
        ],
      ),
    );
  }
}
