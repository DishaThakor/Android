package com.example.lapdealz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
