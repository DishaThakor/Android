import 'dart:convert';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:lapdealz/router/app_router.dart';
import 'package:lapdealz/ui/create_account/create_account_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../api/api_collection.dart';
import '../../values/colors.dart';
import '../../values/style.dart';
import '../../widget/app_text_field.dart';
import '../../widget/custom_full_button.dart';
import 'package:http/http.dart' as http;

@RoutePage()
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController mobileController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  late FocusNode mobileNode;
  ValueNotifier<bool> obscureText = ValueNotifier(false);
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  ValueNotifier<bool> isLoading = ValueNotifier(false);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
        valueListenable: isLoading,
        builder: (context, value, child) {
          return value
              ? const CustomLoading()
              : Scaffold(
                  appBar: AppBar(
                    systemOverlayStyle: SystemUiOverlayStyle.dark,
                    automaticallyImplyLeading: true,
                    forceMaterialTransparency: true,
                    scrolledUnderElevation: 0,
                  ),
                  body: _buildBody(),
                );
        });
  }

  SingleChildScrollView _buildBody() => SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.r),
            child: Column(children: [
              SizedBox(
                height: 40.r,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SvgPicture.asset('assets/images/laptop.svg',
                      height: 80.r,
                      width: 80.r,
                      colorFilter: const ColorFilter.mode(
                        AppColor.primaryPink,
                        BlendMode.srcIn,
                      )),
                  Text(
                    'LapDealz',
                    style: textSemiBold.copyWith(
                      fontSize: 40.sp,
                      color: AppColor.primaryPink,
                    ),
                  )
                ],
              ),
              54.verticalSpace,
              10.verticalSpace,
              AppTextField(
                label: 'Mobile Number',
                hint: 'Mobile Number',
                controller: mobileController,
                keyboardAction: TextInputAction.next,
                keyboardType: TextInputType.number,
                validators: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter mobile number';
                  }
                  return null;
                },
              ),
              20.verticalSpace,
              ValueListenableBuilder(
                  valueListenable: obscureText,
                  builder: (context, value, child) {
                    return AppTextField(
                        controller: passwordController,
                        validators: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter password';
                          }
                          return null;
                        },
                        keyboardAction: TextInputAction.done,
                        label: 'Password',
                        hint: 'Password',
                        obscureText: !obscureText.value,
                        suffixIcon: IconButton(
                            onPressed: () {
                              obscureText.value = !obscureText.value;
                            },
                            icon: obscureText.value
                                ? SvgPicture.asset(
                                    'assets/images/passwordShow.svg')
                                : SvgPicture.asset(
                                    'assets/images/passwordHide.svg')));
                  }),
              40.verticalSpace,
              CustomFullButton(
                title: 'Login',
                bgColor: AppColor.primaryPink,
                titleColor: AppColor.white,
                ontap: () {
                  if (_formKey.currentState!.validate()) {
                    login();
                    // appRouter.replaceAll([const BotomNavigationRoute()]);
                  }
                },
              ),
              20.verticalSpace,
              RichText(
                  text: TextSpan(children: [
                TextSpan(
                  text: 'Don\'t have an account?',
                  style: textRegular.copyWith(
                    color: AppColor.lightBlack.withOpacity(0.5),
                    fontSize: 14.sp,
                  ),
                ),
                TextSpan(
                  text: " Create Account",
                  style: textRegular.copyWith(
                    color: AppColor.primaryPink,
                    fontSize: 14.sp,
                  ),
                  recognizer: TapGestureRecognizer()
                    ..onTap = () {
                      appRouter.replace(const CreateAccountRoute());
                    },
                )
              ])),
            ]),
          ),
        ),
      );

  Future<void> login() async {
    isLoading.value = true;
    final url = '${ApiList.baseUrl}/login';
    try {
      final response = await http.post(
        Uri.parse(url),
        body: {
          'mobile_no': mobileController.text,
          'password': passwordController.text,
        },
      );
      final data = jsonDecode(response.body);
      if (response.statusCode == 200) {
        print(response.body);
        final token = data['data']['token'];
        if (token != null) {
          final SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString('auth_token', token);
          mobileController.clear();
          passwordController.clear();
          appRouter.replaceAll([const BotomNavigationRoute()]);
        } else {
          mobileController.clear();
          passwordController.clear();
          showError('Token not found');
        }
      } else {
        mobileController.clear();
        passwordController.clear();
        showError(data['message'] ?? 'Login failed');
      }
    } catch (e) {
      mobileController.clear();
      passwordController.clear();
      showError('Error: $e');
    } finally {
      isLoading.value = false;
    }
  }

  void showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
}
