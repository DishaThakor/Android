import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lapdealz/ui/create_account/create_account_page.dart';
import 'package:lapdealz/values/style.dart';
import 'package:lapdealz/widget/app_image.dart';
import 'package:lapdealz/widget/app_text_field.dart';
import 'package:lapdealz/widget/custom_full_button.dart';
import '../../api/api_collection.dart';
import '../../values/colors.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

@RoutePage()
class ProductListPage extends StatefulWidget {
  const ProductListPage({super.key});

  @override
  _ProductListPageState createState() => _ProductListPageState();
}

class _ProductListPageState extends State<ProductListPage> {
  late Future<List<dynamic>> _productsFuture;
  final ValueNotifier<String> _searchQuery = ValueNotifier('');
  List<dynamic> _allProducts = [];
  ValueNotifier<bool> isLoading = ValueNotifier(false);

  @override
  void initState() {
    super.initState();
    _productsFuture = _fetchProducts();
  }

  Future<List<dynamic>> _fetchProducts() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final authToken = prefs.getString('auth_token');

    if (authToken == null) {
      throw Exception('Token not found');
    }
    final url = '${ApiList.baseUrl}/products';
    final response = await http.get(
      Uri.parse(url),
      headers: {
        'Authorization': 'Bearer $authToken',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final List<dynamic> products = json.decode(response.body);
      _allProducts = products;
      return products;
    } else {
      throw Exception('Failed to load products');
    }
  }

  List<dynamic> _filterProducts(String query) {
    if (query.isEmpty) {
      return _allProducts;
    }
    return _allProducts.where((product) {
      return product['category'].toLowerCase().contains(query.toLowerCase());
    }).toList();
  }

  Future<void> _addToCart(String productId) async {
    isLoading.value = true;
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final authToken = prefs.getString('auth_token');

    if (authToken == null) {
      throw Exception('Token not found');
    }

    final url = Uri.parse('${ApiList.baseUrl}/cartAdd');
    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $authToken',
          'Content-Type': 'application/json', // Change to application/json
        },
        body: jsonEncode({
          'product_id': productId,
          'quantity': 1,
        }),
      );

      if (response.statusCode == 202) {
        final data = jsonDecode(response.body);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message']),
            backgroundColor: AppColor.primaryPink,
          ),
        );
      } else {
        final data = jsonDecode(response.body);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message'] ?? 'Failed to add product to cart'),
            backgroundColor: AppColor.primaryPink,
          ),
        );
      }
      isLoading.value = false;
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to add product to cart: $e'),
          backgroundColor: AppColor.primaryPink,
        ),
      );
      isLoading.value = false;
    } finally {
      isLoading.value = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
        valueListenable: isLoading,
        builder: (context, isLoadingValue, child) {
          return isLoadingValue
              ? CustomLoading()
              : Scaffold(
                  body: Column(
                    children: [
                      10.verticalSpace,
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20.r),
                        child: AppTextField(
                          label: 'Search by company name..',
                          hint: 'Search by company name..',
                          onChanged: (p0) {
                            _searchQuery.value = p0.toString();
                          },
                          floatingLabelBehavior: FloatingLabelBehavior.never,
                        ),
                      ),
                      20.verticalSpace,
                      Expanded(
                        child: FutureBuilder<List<dynamic>>(
                          future: _productsFuture,
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.waiting) {
                              return const CustomLoading();
                            } else if (snapshot.hasError) {
                              return Center(
                                  child: Text('Error: ${snapshot.error}'));
                            } else if (!snapshot.hasData ||
                                snapshot.data!.isEmpty) {
                              return const Center(
                                  child: Text('No products found.'));
                            }

                            return ValueListenableBuilder<String>(
                              valueListenable: _searchQuery,
                              builder: (context, query, child) {
                                final products = _filterProducts(query);

                                return ListView.separated(
                                  itemCount: products.length,
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 20.r),
                                  separatorBuilder: (context, index) =>
                                      10.verticalSpace,
                                  itemBuilder: (context, index) {
                                    return CustomList(
                                      product: products[index],
                                      onAddToCart: () => _addToCart(
                                          products[index]['id'].toString()),
                                    );
                                  },
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                );
        });
  }

  Widget CustomList(
      {required dynamic product, required VoidCallback onAddToCart}) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(
          color: AppColor.santasGray.withOpacity(0.5),
          width: 1.r,
        ),
      ),
      padding: EdgeInsets.all(10.r),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          AppImage(
            boxFit: BoxFit.contain,
            url: '${ApiList.baseImageUrl}/storage/${product['image']}',
            height: 100.r,
            width: 100.r,
          ),
          10.horizontalSpace,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  maxLines: 3,
                  overflow: TextOverflow.clip,
                  product['title'],
                  style: textMedium.copyWith(
                      fontSize: 15.sp, color: AppColor.black),
                ),
                Text(
                  product['category'],
                  style: textMedium.copyWith(
                      fontSize: 15.sp, color: AppColor.black),
                ),
                Text(
                  '₹ ${product['price'].toString()}',
                  style: textMedium.copyWith(
                      fontSize: 15.sp, color: AppColor.black),
                ),
                CustomFullButton(
                  height: 40.r,
                  title: 'Add to Cart',
                  textStyle: textRegular.copyWith(
                      fontSize: 10.spMin, color: AppColor.white),
                  ontap: onAddToCart,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
