import 'dart:convert';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:lapdealz/ui/cart/cart_page.dart';
import 'package:lapdealz/ui/home/home_page.dart';
import 'package:lapdealz/ui/product/product_list_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../api/api_collection.dart';
import '../../router/app_router.dart';
import '../../values/colors.dart';
import '../../values/style.dart';
import 'package:http/http.dart' as http;

@RoutePage()
class BotomNavigationPage extends StatefulWidget {
  const BotomNavigationPage({super.key});

  @override
  State<BotomNavigationPage> createState() => _BotomNavigationPageState();
}

class _BotomNavigationPageState extends State<BotomNavigationPage> {
  late ValueNotifier<int> _selectedIndex;

  @override
  void initState() {
    super.initState();
    _selectedIndex = ValueNotifier(0);
  }

  var pageList = [
    // const HomePage(),
    const HomePage(),
    const ProductListPage(),
    const CartPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.white,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        title: Row(
          children: [
            SvgPicture.asset('assets/images/laptop.svg',
                height: 40.r,
                width: 40.r,
                colorFilter: const ColorFilter.mode(
                  AppColor.black,
                  BlendMode.srcIn,
                )),
            10.horizontalSpace,
            Text(
              'LapDealz',
              style:
                  textMedium.copyWith(fontSize: 20.sp, color: AppColor.black),
            ),
          ],
        ),
        actions: [
          // Icon(
          //   Icons.shopify_sharp,
          //   color: AppColor.black,
          //   size: 35.r,
          // ),
          5.horizontalSpace,
          GestureDetector(
            onTap: () => _showLogoutDialog(),
            child: Icon(
              Icons.power_settings_new_rounded,
              color: AppColor.black,
              size: 30.r,
            ),
          ),
          10.horizontalSpace,
        ],
        backgroundColor: AppColor.primaryPinkLight,
      ),
      body: ValueListenableBuilder(
        valueListenable: _selectedIndex,
        builder: (context, value, child) {
          return pageList[value];
        },
      ),
      bottomNavigationBar: ValueListenableBuilder(
        valueListenable: _selectedIndex,
        builder: (context, value, child) {
          return BottomNavigationBar(
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.laptop),
                label: 'Products',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart),
                label: 'Cart',
              ),
            ],
            selectedItemColor: AppColor.primaryPink,
            unselectedItemColor: AppColor.black,
            showUnselectedLabels: true,
            showSelectedLabels: true,
            type: BottomNavigationBarType.fixed,
            backgroundColor: AppColor.white,
            currentIndex: value,
            onTap: (index) {
              _selectedIndex.value = index;
            },
          );
        },
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Logout'),
        content: Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _logout();
            },
            child: Text('Logout'),
          ),
        ],
      ),
    );
  }

  Future<void> _logout() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final authToken = prefs.getString('auth_token');
    if (authToken == null) {
      _showError('Auth token not found');
      return;
    } else {
      await prefs.remove('auth_token');
      appRouter.replaceAll([const LoginRoute()]);
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
}
