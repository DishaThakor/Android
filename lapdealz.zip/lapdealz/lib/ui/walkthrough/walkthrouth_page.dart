import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lapdealz/router/app_router.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import '../../values/colors.dart';
import '../../values/style.dart';
import '../../widget/custom_full_button.dart';

@RoutePage()
class WalkthrouthPage extends StatefulWidget {
  const WalkthrouthPage({super.key});

  @override
  State<WalkthrouthPage> createState() => _WalkthrouthPageState();
}

class _WalkthrouthPageState extends State<WalkthrouthPage> {
  final PageController controller = PageController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColor.white,
        body: SizedBox(
          height: double.infinity,
          width: double.infinity,
          child: Stack(
            children: [
              PageView(
                physics: const ClampingScrollPhysics(),
                controller: controller,
                children: [
                  _buildPage('assets/images/easyOrderGirl.jpg', 'Easy Order',
                      'Quickly browse and order your favorite laptops with just a few taps.'),
                  _buildPage(
                    'assets/images/deliveryBoy.jpg',
                    'Safe Delivery',
                    'Enjoy fast, secure delivery right to your doorstep.',
                  ),
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  SmoothPageIndicator(
                    controller: controller,
                    count: 2,
                    effect: ExpandingDotsEffect(
                      dotHeight: 6.r,
                      dotWidth: 6.r,
                      expansionFactor: 5.r,
                      activeDotColor: AppColor.primaryPink,
                      dotColor: AppColor.primaryPink.withOpacity(0.4),
                    ),
                  ),
                  25.verticalSpace,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: CustomFullButton(
                      title: 'Get Started',
                      bgColor: AppColor.white,
                      titleColor: AppColor.lightBlack,
                      ontap: () {
                        appRouter.replace(const LoginRoute());
                      },
                    ),
                  )
                ],
              )
            ],
          ),
        ));
  }

  Container _buildPage(String image, String title, String description) {
    return Container(
      height: double.infinity,
      width: double.infinity,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage(
            image,
          ),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 45.r,
            width: double.infinity,
            decoration: const BoxDecoration(
                gradient: LinearGradient(
              colors: [AppColor.black, AppColor.transparent],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.0, 0.8],
            )),
          ),
          const Spacer(),
          Container(
              height: 405.r,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColor.black,
                    AppColor.walkthroughShades1.withOpacity(0.98),
                    AppColor.walkthroughShades2.withOpacity(0.92),
                    AppColor.walkthroughShades3.withOpacity(0.79),
                    AppColor.walkthroughShades4.withOpacity(0.0)
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
              child: Padding(
                  padding:
                      EdgeInsets.only(left: 20.r, right: 20.r, bottom: 120.r),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      const Spacer(),
                      Text(
                        title,
                        style: textBold.copyWith(
                            color: AppColor.white, fontSize: 26.spMin),
                      ),
                      11.verticalSpace,
                      Flexible(
                          fit: FlexFit.tight,
                          child: Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.r),
                            child: Text(
                              maxLines: 4,
                              textAlign: TextAlign.center,
                              description,
                              style: textRegular.copyWith(
                                  color: AppColor.white.withOpacity(0.7),
                                  fontSize: 16.spMin),
                            ),
                          )),
                    ],
                  )))
        ],
      ),
    );
  }
}
