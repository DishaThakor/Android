import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:lapdealz/values/colors.dart';
import 'package:lapdealz/values/style.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../router/app_router.dart';

@RoutePage()
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    initSetting();
    super.initState();
  }

  Future<void> initSetting() async {
    Future.delayed(const Duration(seconds: 2), () async {
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      final authToken = prefs.getString('auth_token');

      if (authToken != null) {
        appRouter.replace(const BotomNavigationRoute());
      } else {
        appRouter.replace(const WalkthrouthRoute());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SvgPicture.asset('assets/images/laptop.svg',
                height: 80.r,
                width: 80.r,
                colorFilter: const ColorFilter.mode(
                  AppColor.primaryPink,
                  BlendMode.srcIn,
                )),
            Text(
              'LapDealz',
              style: textSemiBold.copyWith(
                fontSize: 40.sp,
                color: AppColor.primaryPink,
              ),
            )
          ],
        ),
      ),
    );
  }
}
