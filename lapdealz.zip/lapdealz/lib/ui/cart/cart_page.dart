import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:http/http.dart' as http;
import 'package:lapdealz/api/api_collection.dart';
import 'dart:convert';

import 'package:lapdealz/ui/cart/cart_model.dart';
import 'package:lapdealz/ui/create_account/create_account_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../values/colors.dart';
import '../../values/style.dart';
import '../../widget/app_image.dart';

// Include your CartItem model

@RoutePage()
class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  Future<List<CartItem>> fetchCartItems() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final authToken = prefs.getString('auth_token');

    if (authToken == null) {
      throw Exception('Token not found');
    }
    final url = Uri.parse('${ApiList.baseUrl}/cart');

    final response = await http.get(
      url,
      headers: {
        'Authorization': 'Bearer $authToken',
        'Content-Type': 'application/json', // Change to application/json
      },
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      List<CartItem> items = (jsonResponse['cartItems'] as List)
          .map((item) => CartItem.fromJson(item))
          .toList();
      return items;
    } else {
      throw Exception('Failed to load cart items');
    }
  }

  Future<void> deleteCartItem(int id) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final authToken = prefs.getString('auth_token');

    if (authToken == null) {
      throw Exception('Token not found');
    }

    final url = Uri.parse('${ApiList.baseUrl}/cart/$id');

    final response = await http.delete(
      url,
      headers: {
        'Authorization': 'Bearer $authToken',
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      setState(() {
        // Refresh the cart items after deletion
        fetchCartItems();
        // ScaffoldMessenger.of(context).showSnackBar(
        //   SnackBar(
        //     content: Text('Order placed successfully'),
        //     backgroundColor: AppColor.primaryPink,
        //   ),
        // );
      });
    } else {
      throw Exception('Failed to delete item from cart');
    }
  }

  Future<void> deleteAllCartItems(List<CartItem> items) async {
    for (var item in items) {
      await deleteCartItem(item.id);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Order placed successfully'),
          backgroundColor: AppColor.primaryPink,
        ),
      );
    }
    // After deleting all items, you can refresh the cart items
    setState(() {
      fetchCartItems();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<List<CartItem>>(
        future: fetchCartItems(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CustomLoading();
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No items in cart'));
          }

          final cartItems = snapshot.data!;

          double totalPrice =
              cartItems.fold(0, (sum, item) => sum + item.product.price);

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              10.verticalSpace,
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.r),
                child: Text(
                  'Total Items: (${cartItems.length})',
                  style: textMedium.copyWith(
                    fontSize: 15.sp,
                    color: AppColor.black,
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.r),
                  child: ListView.separated(
                    separatorBuilder: (context, index) => Divider(
                      color: AppColor.santasGray.withOpacity(0.1),
                      height: 1.r,
                    ),
                    itemCount: cartItems.length,
                    itemBuilder: (context, index) {
                      return CartProduct(cartItem: cartItems[index]);
                    },
                  ),
                ),
              ),
              10.verticalSpace,
              GestureDetector(
                onTap: () {
                  deleteAllCartItems(cartItems);
                },
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20.r,
                  ),
                  margin: EdgeInsets.symmetric(
                    horizontal: 20.r,
                  ),
                  height: 50.r,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6.r),
                    color: AppColor.primaryPink,
                  ),
                  child: Row(
                    children: [
                      Text(
                        'Checkout',
                        style: textSemiBold.copyWith(
                          fontSize: 18.sp,
                          color: AppColor.white,
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: 1.r,
                          decoration: const BoxDecoration(
                            color: AppColor.black,
                            gradient: LinearGradient(
                              colors: [
                                Color.fromARGB(255, 252, 122, 159),
                                AppColor.primaryPinkLight,
                              ],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                          ),
                        ),
                      ),
                      10.horizontalSpace,
                      Text('₹ ${totalPrice.toStringAsFixed(2)}',
                          style: textSemiBold.copyWith(
                            fontSize: 18.sp,
                            color: AppColor.white,
                          ))
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.r),
                child: Text(
                  maxLines: 2,
                  'when you checkout your order will be delivered in 1-2 weeks.',
                  style: textLight.copyWith(
                    fontSize: 10.sp,
                    color: AppColor.black,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget CartProduct({required CartItem cartItem}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10.r),
      child: Row(
        children: [
          AppImage(
            url: '${ApiList.baseImageUrl}/storage/${cartItem.product.image}',
            height: 50.r,
            width: 50.r,
          ),
          10.horizontalSpace,
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  maxLines: 2,
                  overflow: TextOverflow.clip,
                  cartItem.product.title,
                  style: textMedium.copyWith(
                    fontSize: 14.sp,
                    color: AppColor.black,
                  ),
                ),
                10.verticalSpace,
                GestureDetector(
                  onTap: () {
                    deleteCartItem(cartItem.id);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20.r),
                      border: Border.all(
                        color: AppColor.santasGray.withOpacity(0.5),
                        width: 1.r,
                      ),
                    ),
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 10.r, vertical: 5.r),
                      child: Text(
                        'Remove from cart',
                        style: textRegular.copyWith(
                          fontSize: 14.sp,
                          color: AppColor.black,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Text(
            '₹ ${cartItem.product.price}',
            style: textSemiBold.copyWith(
              fontSize: 15.sp,
              color: AppColor.black,
            ),
          ),
        ],
      ),
    );
  }
}
