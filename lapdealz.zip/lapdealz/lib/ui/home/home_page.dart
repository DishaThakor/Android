import 'package:auto_route/auto_route.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lapdealz/values/colors.dart';
import 'package:lapdealz/values/style.dart';

@RoutePage()
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> imgList = [
    'assets/images/slider1.avif',
    'assets/images/slider2.jpg',
    'assets/images/slider3.avif',
    'assets/images/slider4.avif',
  ];

  List<Category> categoryList = [
    Category(name: 'Apple', image: 'assets/images/apple.png'),
    Category(name: 'Hp', image: 'assets/images/hp.png'),
    Category(name: 'Lenovo', image: 'assets/images/lenovo.png'),
    Category(name: 'Msi', image: 'assets/images/msi.jpg'),
    Category(name: 'Asus', image: 'assets/images/asus.png'),
    Category(name: 'Dell', image: 'assets/images/dell.png'),
  ];

  int _current = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.white,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          20.verticalSpace,
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.r),
            child: Row(
              children: [
                Text(
                  'Shop Our Collection',
                  style: textMedium.copyWith(
                      fontSize: 18.sp, color: AppColor.black),
                ),
                10.horizontalSpace,
                Expanded(
                  child: Container(
                    height: 1.r,
                    decoration: const BoxDecoration(
                      color: AppColor.black,
                      gradient: LinearGradient(
                        colors: [
                          AppColor.primaryPink,
                          Color.fromARGB(210, 255, 138, 171),
                          AppColor.primaryPinkLight,
                        ],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
          10.verticalSpace,
          SizedBox(
              height: 150.r,
              child: ListView.separated(
                  separatorBuilder: (context, index) => 10.horizontalSpace,
                  padding: EdgeInsets.zero,
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemCount: categoryList.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: EdgeInsets.only(
                        left: index == 0 ? 20.r : 0.r,
                        right: index == categoryList.length ? 20.r : 0.r,
                      ),
                      child: Column(
                        children: [
                          Container(
                            height: 70.r,
                            width: 70.r,
                            decoration: BoxDecoration(
                                color: AppColor.transparent,
                                borderRadius: BorderRadius.circular(5.r),
                                border: Border.all(
                                  color: AppColor.primaryPink,
                                  width: 1.r,
                                )),
                            child: Center(
                              child: Image.asset(
                                categoryList[index].image,
                                height: 40.r,
                                width: 40.r,
                              ),
                            ),
                          ),
                          5.verticalSpace,
                          Text(
                            categoryList[index].name,
                            style: textMedium.copyWith(
                                fontSize: 12.sp, color: AppColor.black),
                          )
                        ],
                      ),
                    );
                  })),
          CarouselSlider(
            items: imgList.map((item) {
              return SizedBox(
                height: 40.r,
                width: 1.sw * 0.9.w,
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(5.r),
                    child: Image.asset(
                      item,
                      fit: BoxFit.fill,
                    )),
              );
            }).toList(),
            options: CarouselOptions(
              enlargeCenterPage: true,
              viewportFraction: 0.9,
              autoPlay: true,
              autoPlayInterval: const Duration(seconds: 3),
              autoPlayAnimationDuration: const Duration(milliseconds: 800),
              autoPlayCurve: Curves.fastOutSlowIn,
              enableInfiniteScroll: true,
              onPageChanged: (index, reason) {
                setState(() {
                  _current = index;
                });
              },
            ),
          ),
          SizedBox(
            height: 10.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: imgList.map((entry) {
              return Container(
                width: _current != imgList.indexOf(entry) ? 4.0.w : 20.0.w,
                height: 5.0.h,
                margin:
                    EdgeInsets.symmetric(vertical: 8.0.sp, horizontal: 4.0.sp),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(50.0),
                    color: _current != imgList.indexOf(entry)
                        ? Colors.grey
                        : AppColor.primaryPink),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class Category {
  final String name;
  final String image;

  Category({required this.name, required this.image});
}
