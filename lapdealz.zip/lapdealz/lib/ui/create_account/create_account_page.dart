import 'dart:convert';
import 'package:auto_route/auto_route.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:lapdealz/router/app_router.dart';
import '../../api/api_collection.dart';
import '../../values/colors.dart';
import '../../values/style.dart';
import '../../widget/app_text_field.dart';
import '../../widget/custom_full_button.dart';
import 'package:http/http.dart' as http;

@RoutePage()
class CreateAccountPage extends StatefulWidget {
  const CreateAccountPage({super.key});

  @override
  State<CreateAccountPage> createState() => _CreateAccountPageState();
}

class _CreateAccountPageState extends State<CreateAccountPage> {
  TextEditingController mobileController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  late FocusNode mobileNode;
  ValueNotifier<bool> obscureText = ValueNotifier(false);
  ValueNotifier<bool> obscureTextConfirm = ValueNotifier(false);
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  ValueNotifier<bool> isLoading = ValueNotifier(false);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: isLoading,
      builder: (context, value, child) {
        return value
            ? const CustomLoading()
            : Scaffold(
                appBar: AppBar(
                  systemOverlayStyle: SystemUiOverlayStyle.dark,
                  automaticallyImplyLeading: true,
                  forceMaterialTransparency: true,
                  scrolledUnderElevation: 0,
                ),
                body: _buildBody(),
              );
      },
    );
  }

  SingleChildScrollView _buildBody() => SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.r),
            child: Column(children: [
              SizedBox(
                height: 40.r,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SvgPicture.asset('assets/images/laptop.svg',
                      height: 80.r,
                      width: 80.r,
                      colorFilter: const ColorFilter.mode(
                        AppColor.primaryPink,
                        BlendMode.srcIn,
                      )),
                  Text(
                    'LapDealz',
                    style: textSemiBold.copyWith(
                      fontSize: 40.sp,
                      color: AppColor.primaryPink,
                    ),
                  )
                ],
              ),
              54.verticalSpace,
              10.verticalSpace,
              AppTextField(
                label: 'Mobile Number',
                hint: 'Mobile Number',
                controller: mobileController,
                keyboardAction: TextInputAction.next,
                keyboardType: TextInputType.number,
                validators: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter mobile number';
                  }
                  return null;
                },
              ),
              20.verticalSpace,
              ValueListenableBuilder(
                  valueListenable: obscureText,
                  builder: (context, value, child) {
                    return AppTextField(
                        controller: passwordController,
                        validators: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter password';
                          }
                          return null;
                        },
                        keyboardAction: TextInputAction.done,
                        label: 'Password',
                        hint: 'Password',
                        obscureText: !obscureText.value,
                        suffixIcon: IconButton(
                            onPressed: () {
                              obscureText.value = !obscureText.value;
                            },
                            icon: obscureText.value
                                ? SvgPicture.asset(
                                    'assets/images/passwordShow.svg')
                                : SvgPicture.asset(
                                    'assets/images/passwordHide.svg')));
                  }),
              20.verticalSpace,
              ValueListenableBuilder(
                  valueListenable: obscureTextConfirm,
                  builder: (context, value, child) {
                    return AppTextField(
                        controller: confirmPasswordController,
                        validators: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter confirm password';
                          }
                          if (value != passwordController.text) {
                            return 'Password not match';
                          }
                          return null;
                        },
                        keyboardAction: TextInputAction.done,
                        label: 'Confirm Password',
                        hint: 'Confirm Password',
                        obscureText: !obscureTextConfirm.value,
                        suffixIcon: IconButton(
                            onPressed: () {
                              obscureTextConfirm.value =
                                  !obscureTextConfirm.value;
                            },
                            icon: obscureTextConfirm.value
                                ? SvgPicture.asset(
                                    'assets/images/passwordShow.svg')
                                : SvgPicture.asset(
                                    'assets/images/passwordHide.svg')));
                  }),
              40.verticalSpace,
              CustomFullButton(
                title: 'Create Account',
                bgColor: AppColor.primaryPink,
                titleColor: AppColor.white,
                ontap: () {
                  if (_formKey.currentState!.validate()) {
                    register();
                  }
                },
              ),
              20.verticalSpace,
              RichText(
                  text: TextSpan(children: [
                TextSpan(
                  text: 'Already have an account? ',
                  style: textRegular.copyWith(
                    color: AppColor.lightBlack.withOpacity(0.5),
                    fontSize: 14.sp,
                  ),
                ),
                TextSpan(
                  text: " Login",
                  style: textRegular.copyWith(
                    color: AppColor.primaryPink,
                    fontSize: 14.sp,
                  ),
                  recognizer: TapGestureRecognizer()
                    ..onTap = () {
                      appRouter.replace(const LoginRoute());
                    },
                )
              ])),
            ]),
          ),
        ),
      );

  Future<void> register() async {
    isLoading.value = true;

    final url = Uri.parse('${ApiList.baseUrl}/signup');
    try {
      final response = await http.post(url, body: {
        'mobile_no': mobileController.text,
        'password': passwordController.text,
      });

      final data = jsonDecode(response.body);

      if (response.statusCode == 201) {
        mobileController.clear();
        passwordController.clear();
        confirmPasswordController.clear();
        appRouter.replace(const LoginRoute());
      } else {
        print('status code : ${response.statusCode}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(data['message'])),
        );
        // mobileController.clear();
        // passwordController.clear();
        // confirmPasswordController.clear();
      }
    } catch (e) {
      // Handle network error
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('An error occurred. Please try again.')),
      );
      // mobileController.clear();
      // passwordController.clear();
      // confirmPasswordController.clear();
    } finally {
      isLoading.value = false;
    }
  }
}

class CustomLoading extends StatelessWidget {
  const CustomLoading({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SvgPicture.asset('assets/images/laptop.svg',
              height: 80.r,
              width: 80.r,
              colorFilter: const ColorFilter.mode(
                AppColor.primaryPink,
                BlendMode.srcIn,
              )),
          SizedBox(
            width: 100.r,
            child: const LinearProgressIndicator(
              color: AppColor.primaryPink,
              backgroundColor: AppColor.primaryPinkLight,
            ),
          ),
        ],
      )),
    );
  }
}
