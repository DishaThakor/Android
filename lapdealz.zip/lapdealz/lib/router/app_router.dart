import 'package:auto_route/auto_route.dart';
import '../ui/bottom/botom_navigation_page.dart';
import '../ui/cart/cart_page.dart';
import '../ui/create_account/create_account_page.dart';
import '../ui/home/home_page.dart';
import '../ui/login/login_page.dart';
import '../ui/product/product_list_page.dart';
import '../ui/splash/splash_page.dart';
import '../ui/walkthrough/walkthrouth_page.dart';
part 'app_router.gr.dart';

@AutoRouterConfig(
  replaceInRouteName: 'Page|Screen,Route',
)
class AppRouter extends RootStackRouter {
  @override
  RouteType get defaultRouteType => const RouteType.material();

  @override
  final List<AutoRoute> routes = [
    // splash
    AutoRoute(page: SplashRoute.page, initial: true),
    // walkthrough
    AutoRoute(page: WalkthrouthRoute.page),
    // login
    AutoRoute(page: LoginRoute.page),
    // create account
    AutoRoute(page: CreateAccountRoute.page),
    // bottom navigation bar
    AutoRoute(page: BotomNavigationRoute.page),
    // home
    AutoRoute(page: HomeRoute.page),
    // product list
    AutoRoute(page: ProductListRoute.page),
    // cart
    AutoRoute(page: CartRoute.page),
  ];
}

final appRouter = AppRouter();
