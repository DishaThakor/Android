import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../values/colors.dart';
import '../values/style.dart';

class CustomFullButton extends StatelessWidget {
  final String? title;
  final Color? bgColor;
  final Color? titleColor;
  final VoidCallback? ontap;
  final double? height;
  final double? width;
  final double? fontSize;
  final double? radius;
  final TextStyle? textStyle;
  final Border? border;
  final Gradient? gradient;

  const CustomFullButton(
      {super.key,
      this.title,
      this.bgColor,
      this.titleColor,
      this.ontap,
      this.height,
      this.width,
      this.fontSize,
      this.radius,
      this.textStyle,
      this.border,
      this.gradient});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: ontap,
      child: Container(
        height: height ?? 50.h,
        width: width ?? double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius ?? 6.r),
          color: bgColor ?? AppColor.primaryPink,
          border: border,
          gradient: gradient,
        ),
        child: Center(
          child: Text(
            title ?? 'Submit',
            style: textSemiBold.copyWith(
                color: titleColor ?? AppColor.white,
                fontSize: fontSize ?? 18.spMin),
          ),
        ),
      ),
    );
  }
}
