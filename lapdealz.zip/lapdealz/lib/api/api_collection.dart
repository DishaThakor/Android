class ApiList {
  static String baseUrl =
      "https://5c69-2409-40c1-59-b2a5-1d81-7b3c-b452-72dc.ngrok-free.app/api";

  static String baseImageUrl =
      "https://5c69-2409-40c1-59-b2a5-1d81-7b3c-b452-72dc.ngrok-free.app";
}
