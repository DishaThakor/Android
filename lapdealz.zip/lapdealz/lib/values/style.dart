import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:lapdealz/values/colors.dart';

final TextStyle textThin = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w100,
    fontSize: 16.spMin,
    color: AppColor.black,
    fontFamily: 'Sofia');
final TextStyle textExtraLight = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w200,
    fontSize: 16.spMin,
    color: AppColor.black,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia');
final TextStyle textLight = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w300,
    fontSize: 16.spMin,
    color: AppColor.black,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia');
final TextStyle textRegular = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w400,
    fontSize: 16.spMin,
    color: AppColor.black,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia');
final TextStyle textMedium = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w500,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);
final TextStyle textSemiBold = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w600,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia');
final TextStyle textBold = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w700,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia');
final TextStyle textExtraBold = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w800,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);
final TextStyle textBlack = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w900,
    fontSize: 26.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle selectedWhiteText = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w700,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle deSelectedWhiteText = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w600,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle navigationTitleStyle = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w800,
    fontSize: 18.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle titleText = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w600,
    fontSize: 26.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: Colors.black);

final TextStyle descriptionText = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w400,
    fontSize: 14.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle textSemiBold18Sp = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w600,
    fontSize: 18.spMin,
    overflow: TextOverflow.ellipsis,
    color: AppColor.black,
    fontFamily: 'Sofia');

final TextStyle w400SpMin12 = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w400,
    fontSize: 12.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle w500SpMin14Black = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w500,
    fontSize: 14.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle w600SpMin14Blue = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w600,
    fontSize: 14.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle w600SpMin16Blue = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w600,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);

final TextStyle w600SpMin16Pink = TextStyle(
    decoration: TextDecoration.none,
    fontWeight: FontWeight.w600,
    fontSize: 16.spMin,
    overflow: TextOverflow.ellipsis,
    fontFamily: 'Sofia',
    color: AppColor.black);
