import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lapdealz/values/colors.dart';
import 'package:lapdealz/values/style.dart';

final ThemeData appTheme = ThemeData(
  dialogBackgroundColor: AppColor.white,
  primaryColor: AppColor.primaryPink,
  scaffoldBackgroundColor: const Color(0xfff9f9f9),
  visualDensity: VisualDensity.adaptivePlatformDensity,
  appBarTheme: AppBarTheme(
    systemOverlayStyle: const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarBrightness: Brightness.dark,
// For Android
      statusBarIconBrightness: Brightness.dark,
// For iOS
      systemNavigationBarColor: Colors.transparent, // Navigation bar
    ),
    color: AppColor.primaryPink,
    iconTheme: const IconThemeData(color: AppColor.white, size: 30.0),
    toolbarTextStyle: TextTheme(
      titleLarge: textBold,
    ).bodyMedium,
    titleTextStyle: TextTheme(
      titleLarge: textBold,
    ).titleLarge,
  ),
  buttonTheme: const ButtonThemeData(
    buttonColor: AppColor.white,
    disabledColor: AppColor.white,
  ),
  colorScheme:
      ColorScheme.fromSwatch().copyWith(secondary: AppColor.primaryPink),
);
