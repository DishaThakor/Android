import 'package:flutter/material.dart';

abstract class AppColor {
  static const Color primaryPink = Color(0xFFFF729B);
  static const Color primaryPinkLight = Color(0xFFFFDBE6);
  static const Color lightBlack = Color(0XFF121111);
  static const Color backgroundSmockWhite = Color(0XFFFDF7F7);
  static const Color toolbarColor = Color(0xFFc9c9c9);
  static const Color santasGray = Color(0xff9FA2AA);

  // static color
  static const Color black = Colors.black;
  static const Color white = Colors.white;
  static const Color transparent = Colors.transparent;
  static const Color red = Colors.red;

  // Walkthrough shades
  static const Color walkthroughShades1 = Color(0XFF020202);
  static const Color walkthroughShades2 = Color(0XFF080808);
  static const Color walkthroughShades3 = Color(0XFF151515);
  static const Color walkthroughShades4 = Color(0XFF666666);

  static var primary;
}
